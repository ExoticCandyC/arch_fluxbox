#!/bin/sh

var1=$(( $RANDOM % 4 ))

case $var1 in

  0)
    xterm -fa monaco -fs 13 -bg black -fg pink &
    ;;

  1)
    xterm -fa monaco -fs 13 -bg black -fg magenta &
    ;;

  2)
    xterm -fa monaco -fs 13 -bg black -fg violet &
    ;;

  3)
    xterm -fa monaco -fs 13 -bg black -fg deeppink &
    ;;
    
  *)
    echo "error" &
    ;;
esac


