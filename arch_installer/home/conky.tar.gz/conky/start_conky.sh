#gnome-extensions disable dash-to-panel@jderose9.github.com
#sleep 10
#gnome-extensions disable dash-to-dock@micxgx.gmail.com
#sleep 10
#gnome-extensions enable dash-to-dock@micxgx.gmail.com
#sleep 10
#gnome-extensions enable dash-to-panel@jderose9.github.com
#sleep 10



#nautilus & echo "hi"
#sleep 0.1
#killall -9 nautilus
#killall -9 gnome-software
#killall conky
#sleep 0.1
#conky -c ~/.conky/Antares/AntaresOK & echo "hi"
#nautilus

sleep 0.5
xdotool mousemove 960 540 click 1
killall conky
killall -9 gnome-software
sleep 0.5
conky -c ~/.conky/Antares/AntaresOK & echo "hi"
